@extends('layouts.library')

@section('title', 'Xem văn bản')

@section('content')
    <section class="space-y-5">
        <div class="rounded-sm border border-slate-200 bg-white p-5 shadow-[0_18px_44px_-36px_rgba(15,23,42,0.35)]">
            <div class="mb-4">
                <h1 class="text-xl font-semibold text-slate-900">Xem văn bản</h1>
                <p class="text-sm text-slate-500">{{ $text->name }} • {{ $text->author }}</p>
            </div>

            <div class="mb-4 flex items-end justify-between gap-3">
                <div class="flex-1">
                    <label class="mb-1 block text-sm font-medium text-slate-700">Tiêu đề văn bản</label>
                    <input type="text" value="{{ $document->title ?? $text->name }}" class="input input-sm !h-10 min-h-10 w-full rounded-sm border border-slate-200 bg-slate-50 text-sm text-slate-800 shadow-none" readonly />
                </div>
                <div class="shrink-0">
                    <p class="mb-1 text-sm font-medium text-slate-700">Nhập/Xuất</p>
                    <div class="flex items-center gap-2">
                        <form id="writer_import_form" action="{{ route('admin.texts.writer.import-docx', $text) }}" method="POST" enctype="multipart/form-data" class="m-0">
                            @csrf
                            <input id="writer_import_file" type="file" name="import_file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" class="hidden" />
                            <button type="button" id="writer_import_button" class="btn btn-sm !h-10 min-h-10 rounded-sm border border-slate-200 bg-white px-4 text-slate-700 shadow-none hover:bg-slate-50">Nhập DOCX</button>
                        </form>
                        <a href="{{ route('admin.texts.writer.export-docx', $text) }}" id="writer_export_button" class="btn btn-sm !h-10 min-h-10 rounded-sm border border-slate-200 bg-white px-4 text-slate-700 shadow-none hover:bg-slate-50">Xuất DOCX</a>
                    </div>
                </div>
            </div>

            @if (!empty($previewError))
                <div class="mb-4 rounded-sm border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-700">
                    {{ $previewError }}
                </div>
            @endif

            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">Nội dung văn bản (Preview)</label>
                <div class="writer-preview min-h-[60vh] overflow-auto rounded-sm border border-slate-200 bg-white p-5">
                    {!! $previewHtml !!}
                </div>
            </div>
        </div>

        <!-- Tệp đính kèm -->
        <div id="text-files-section" class="rounded-sm border border-slate-200 bg-white p-5 shadow-[0_18px_44px_-36px_rgba(15,23,42,0.35)]">
            <div class="mb-4 flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-semibold text-slate-900">Tài liệu đính kèm (Ảnh, Video, Âm thanh)</h2>
                    <p class="text-sm text-slate-500">Quản lý các file đa phương tiện đính kèm của văn bản này</p>
                </div>
                <button type="button" id="add-file-input-btn" class="btn btn-sm !h-10 min-h-10 rounded-sm border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 hover:bg-blue-100">
                    + Thêm file
                </button>
            </div>

            <!-- Danh sách các file đã tải lên -->
            @if($text->textFiles->isNotEmpty())
                <div class="mb-5 border-b border-slate-100 pb-5">
                    <h3 class="mb-3 text-sm font-semibold text-slate-700">Các file đã tải lên:</h3>
                    <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        @foreach($text->textFiles as $file)
                            <div class="flex items-center justify-between rounded-sm border border-slate-200 bg-slate-50 p-3">
                                <div class="min-w-0 flex-1 pr-3">
                                    <p class="truncate text-sm font-medium text-slate-800" title="{{ $file->file_name }}">
                                        {{ $file->file_name }}
                                    </p>
                                    <div class="mt-1 flex items-center gap-2 text-xs text-slate-500">
                                        <span class="rounded bg-slate-200 px-1.5 py-0.5 font-semibold uppercase text-slate-600">
                                            {{ $file->file_type }}
                                        </span>
                                        @if($file->file_size)
                                            <span>•</span>
                                            <span>{{ number_format($file->file_size / 1024, 1) }} KB</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="flex items-center gap-2 shrink-0">
                                    <a href="{{ route('texts.files.serve', ['text' => $text, 'filename' => basename($file->file_path)]) }}" target="_blank" class="text-xs font-medium text-blue-600 hover:text-blue-700">
                                        Xem
                                    </a>
                                    <span class="text-slate-300">|</span>
                                    <form method="POST" action="{{ route('admin.texts.writer.destroy-file', [$text, $file]) }}" class="m-0 inline-block" data-confirm-delete="true" data-confirm-message="Bạn chắc chắn muốn xóa file này?">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-xs font-medium text-rose-600 hover:text-rose-700">
                                            Xóa
                                        </button>
                                    </form>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif

            <!-- Form tải lên file mới -->
            <form id="upload-files-form" action="{{ route('admin.texts.writer.store-files', $text) }}" method="POST" enctype="multipart/form-data" class="hidden space-y-4">
                @csrf
                <div id="file-inputs-container" class="grid gap-3 sm:grid-cols-2">
                    <!-- Dynamic file inputs will be appended here -->
                </div>
                <div class="flex justify-end gap-2 border-t border-slate-100 pt-4">
                    <button type="button" id="cancel-upload-btn" class="btn btn-ghost btn-sm !h-10 min-h-10 rounded-sm border border-slate-200 bg-white px-4 text-slate-700 hover:bg-slate-50">
                        Hủy
                    </button>
                    <button type="submit" class="btn btn-primary btn-sm !h-10 min-h-10 rounded-sm border-0 px-4 text-white hover:bg-blue-700">
                        Lưu file
                    </button>
                </div>
            </form>
        </div>

        <div id="comments" class="rounded-sm border border-slate-200 bg-white p-5 shadow-[0_18px_44px_-36px_rgba(15,23,42,0.35)]">
            <div class="mb-4">
                <h2 class="text-lg font-semibold text-slate-900">Bình luận bài học</h2>
                <p class="text-sm text-slate-500">{{ $comments->count() }} bình luận</p>
            </div>

            <div class="space-y-3">
                @forelse ($comments as $comment)
                    <article class="rounded-sm border border-slate-200 bg-white p-4">
                        <div class="flex items-start gap-3">
                            <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-100 text-xs font-semibold uppercase text-blue-700">
                                {{ \Illuminate\Support\Str::of($comment->user->name)->substr(0, 1) }}
                            </div>
                            <div class="min-w-0 flex-1">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <p class="text-sm font-semibold text-slate-800">{{ $comment->user->name }}</p>
                                    <div class="flex items-center gap-3">
                                        <p class="text-xs text-slate-500">{{ $comment->created_at?->format('H:i d/m/Y') }}</p>
                                        @auth
                                            @if (
                                                auth()->user()->role === 'teacher'
                                                || (auth()->user()->role === 'user' && (string) $comment->user_id === (string) auth()->id())
                                            )
                                                <form method="POST" action="{{ route('texts.comments.destroy', [$text, $comment]) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="text-xs font-medium text-rose-600 hover:text-rose-700">
                                                        Xóa
                                                    </button>
                                                </form>
                                            @endif
                                        @endauth
                                    </div>
                                </div>
                                <p class="mt-2 whitespace-pre-line text-sm leading-6 text-slate-700">{{ $comment->content }}</p>
                            </div>
                        </div>
                    </article>
                @empty
                    <div class="rounded-sm border border-dashed border-slate-300 bg-slate-50 px-4 py-5 text-center text-sm text-slate-500">
                        Chưa có bình luận nào cho bài học này.
                    </div>
                @endforelse
            </div>
        </div>
    <!-- Glassmorphic Loading Overlay HTML -->
    <div id="docx-loading-overlay" aria-live="assertive" aria-label="Đang xử lý">
        <div class="docx-loading-card">
            <div class="docx-spinner-wrapper">
                <div class="docx-spinner-outer"></div>
                <div class="docx-spinner-inner"></div>
            </div>
            <h3 id="docx-loading-title" class="text-lg font-semibold text-white mb-2">Đang xử lý</h3>
            <p id="docx-loading-text" class="text-sm text-slate-300">Vui lòng chờ trong giây lát...</p>
        </div>
    </div>
</section>
@endsection

@push('styles')
    <style>
        .writer-preview table {
            width: 100%;
            border-collapse: collapse;
            margin: 0.75rem 0;
        }

        .writer-preview th,
        .writer-preview td {
            border: 1px solid #cbd5e1;
            padding: 0.4rem 0.5rem;
            vertical-align: top;
        }

        .writer-preview p,
        .writer-preview li,
        .writer-preview td,
        .writer-preview th {
            line-height: 1.55;
        }

        .writer-preview img {
            max-width: 100%;
            height: auto;
        }

        /* Modern Glassmorphic Loading Overlay */
        #docx-loading-overlay {
            position: fixed;
            inset: 0;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background-color: rgba(15, 23, 42, 0.75);
            backdrop-filter: blur(8px);
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        #docx-loading-overlay.active {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
        }

        .docx-loading-card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 1.25rem;
            padding: 2.5rem;
            max-width: 380px;
            width: calc(100% - 2rem);
            margin: 1rem;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            transform: scale(0.95);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        #docx-loading-overlay.active .docx-loading-card {
            transform: scale(1);
        }

        .docx-spinner-wrapper {
            position: relative;
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
        }

        .docx-spinner-outer {
            position: absolute;
            inset: 0;
            border-radius: 50%;
            border: 4px solid rgba(59, 130, 246, 0.15);
            border-top-color: #3b82f6;
            border-right-color: #3b82f6;
            animation: docx-spin 0.8s linear infinite;
        }

        .docx-spinner-inner {
            position: absolute;
            inset: 12px;
            border-radius: 50%;
            border: 3px solid rgba(99, 102, 241, 0.1);
            border-bottom-color: #6366f1;
            border-left-color: #6366f1;
            animation: docx-spin-reverse 1.2s linear infinite;
        }

        @keyframes docx-spin {
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes docx-spin-reverse {
            to {
                transform: rotate(-360deg);
            }
        }
    </style>
@endpush

@push('scripts')
    <script>
        (() => {
            const importButton = document.getElementById('writer_import_button');
            const importInput = document.getElementById('writer_import_file');
            const importForm = document.getElementById('writer_import_form');
            const exportButton = document.getElementById('writer_export_button');
            const loadingOverlay = document.getElementById('docx-loading-overlay');
            const loadingTitle = document.getElementById('docx-loading-title');
            const loadingText = document.getElementById('docx-loading-text');

            if (!loadingOverlay) {
                return;
            }

            const showLoading = (title, text) => {
                if (loadingTitle) loadingTitle.textContent = title;
                if (loadingText) loadingText.textContent = text;
                loadingOverlay.classList.add('active');
            };

            const hideLoading = () => {
                loadingOverlay.classList.remove('active');
            };

            if (importButton && importInput && importForm) {
                importButton.addEventListener('click', () => {
                    importInput.click();
                });

                importInput.addEventListener('change', () => {
                    if (!importInput.files || !importInput.files.length) {
                        return;
                    }

                    showLoading('Đang nhập dữ liệu', 'Vui lòng chờ trong giây lát trong khi hệ thống đang xử lý và phân tích tệp DOCX...');
                    importForm.submit();
                });
            }

            if (exportButton) {
                exportButton.addEventListener('click', () => {
                    showLoading('Đang xuất dữ liệu', 'Hệ thống đang khởi tạo và tải xuống tệp DOCX của bạn...');
                    
                    // Since file download won't trigger a page navigation/reload,
                    // we hide the loading screen after a safe duration.
                    setTimeout(() => {
                        hideLoading();
                    }, 4000);
                });
            }

            // Quản lý file đính kèm
            const addFileInputBtn = document.getElementById('add-file-input-btn');
            const uploadFilesForm = document.getElementById('upload-files-form');
            const fileInputsContainer = document.getElementById('file-inputs-container');
            const cancelUploadBtn = document.getElementById('cancel-upload-btn');

            if (addFileInputBtn && uploadFilesForm && fileInputsContainer) {
                const createInputRow = () => {
                    const row = document.createElement('div');
                    row.className = 'flex items-center gap-3 rounded-sm border border-slate-200 bg-slate-50/50 p-3';
                    row.innerHTML = `
                        <div class="flex-1">
                            <input type="file" name="files[]" required class="file-input file-input-bordered file-input-sm w-full bg-white text-sm border-slate-200" accept="image/*,video/*,audio/*" />
                        </div>
                        <button type="button" class="remove-input-row-btn btn btn-sm btn-ghost rounded-sm text-rose-600 hover:bg-rose-50 px-2" title="Xóa dòng này">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                            </svg>
                        </button>
                    `;

                    row.querySelector('.remove-input-row-btn').addEventListener('click', () => {
                        row.remove();
                        if (fileInputsContainer.children.length === 0) {
                            uploadFilesForm.classList.add('hidden');
                        }
                    });

                    return row;
                };

                addFileInputBtn.addEventListener('click', () => {
                    uploadFilesForm.classList.remove('hidden');
                    const newRow = createInputRow();
                    fileInputsContainer.appendChild(newRow);
                });

                if (cancelUploadBtn) {
                    cancelUploadBtn.addEventListener('click', () => {
                        fileInputsContainer.innerHTML = '';
                        uploadFilesForm.classList.add('hidden');
                    });
                }
            }
        })();
    </script>
@endpush
